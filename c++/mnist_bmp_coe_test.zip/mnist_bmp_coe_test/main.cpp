#include <iostream>
#include <sstream>    //引入stringstream头文件
#include <stdio.h>
#include <iomanip>
#include <bits/stdc++.h>
using namespace std ;

#define u8    unsigned char
#define u32   unsigned int

#pragma pack(1)  //这个选项挺重要，不加的话程序就会报错，原因参考
//https://blog.csdn.net/qq_44310495/article/details/109181857

#define CONV1_O 5
#define CONV2_O 10

double data[784];

struct cnn_layer//定义卷积网络中的层，以及
{
    int L,W,C;
    //数据最大是30*30*64
    double data[30][30][64];
    double bias[64];
};
struct fcnn_layer//定义全连接网络中的层
{
    int L;
    //数据最大是4*4*64 10
    double data[1024];
    double bias[10];
    double w[10][1024];
    //batch normalization
    double gamma, beta;
    double u, o2;
    double xhat[1024];
};

cnn_layer input_layer;
cnn_layer conv_layer1;
cnn_layer pool_layer1;
cnn_layer conv_layer2;
cnn_layer pool_layer2;
cnn_layer cnn_w1[CONV1_O];
cnn_layer cnn_w2[CONV2_O];
fcnn_layer fcnn_input1;
fcnn_layer fcnn_output;

typedef struct {
    unsigned char bfType[2];
    unsigned long bfSize;
    unsigned short bfReserved1;
    unsigned short bfReserved2;
    unsigned long bfOffBits;
}bitmapFileHeader;

typedef struct {
    unsigned long biSize;
    long biWidth;
    long biHeight;
    unsigned short biPlanes;
    unsigned short biBitCount;
    unsigned long biCompression;
    unsigned long biSizeImage;
    long biXPixPerMeter;
    long biYPixPerMeter;
    unsigned long biClrused;
    unsigned long biClrImportant;
}bitmapInfoHeader;

//前向传播
cnn_layer CNN_Input(cnn_layer input_image);//将图像输入卷积层
cnn_layer conv(cnn_layer input,cnn_layer conv_w[],int number,cnn_layer output);//卷积函数，表示卷积层A与number个filterB相卷积
cnn_layer maxpooling(cnn_layer conv_layer,cnn_layer pooling_layer);//池化前向输出
fcnn_layer Classify_input(cnn_layer cnn,fcnn_layer fcnn);//将卷积提取特征输入到全连接神经网络
fcnn_layer fcnn_Mul(fcnn_layer input,fcnn_layer output);//全连接层前向输出


void read_bmp(){
    FILE *fp;
    if((fp=fopen("5.bmp","rb"))==NULL){
        perror("can not open file!");
    }

    bitmapFileHeader bfHeader;
    fread(&bfHeader,14,1,fp);
    bitmapInfoHeader biHeader;
    fread(&biHeader,40,1,fp);

    int imSize=biHeader.biSizeImage;
    int width=biHeader.biWidth;
    int height=biHeader.biHeight;
    int bitCount=biHeader.biBitCount;

    fseek(fp,bfHeader.bfOffBits,SEEK_SET);
    unsigned char* imageData = (unsigned char*)malloc(imSize*sizeof(unsigned char));
    fread(imageData,imSize*sizeof(unsigned char),1,fp);

    //图像为8位图像
    int lineBytes=(bitCount*width+31)/32*4;//得到图像数据的bitwidth'
    int i,j;

    for(i=0;i<height;i++){ //对于每一行
        for(j=0;j<width;j++){ //对于每一列
            data[i*28+j] = *(imageData+lineBytes*(height-1-i)+j); //从最后一行往上读
        }
    }

    free(imageData);
    fclose(fp);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

double sigmoid(double x)
{
    return 1.0/(1.0+exp(-x));
}
double Relu(double x)
{
    return max(0.0,x);
}
fcnn_layer softmax(fcnn_layer output)
{
    double sum=0.0; double maxx=-100000000;
    for(int i=0;i<output.L;i++) maxx=max(maxx,output.data[i]);
    for(int i=0;i<output.L;i++) sum+=exp(output.data[i]-maxx);
    for(int i=0;i<output.L;i++) output.data[i]=exp(output.data[i]-maxx)/sum;
    return output;
}

fcnn_layer BN(fcnn_layer x)
{
    //u
    x.u = 0;
    for(int i=0; i<x.L; i++)
        x.u += x.data[i];
    x.u = x.u / x.L;
    //o2
    x.o2 = 0;
    for(int i=0; i<x.L; i++)
        x.o2 += abs(x.data[i]-x.u);//*(x.data[i]-x.u);
    x.o2 = x.o2 / x.L;
    //xhat
    for(int i=0; i<x.L; i++) {
        x.xhat[i] = (x.data[i] - x.u) / x.o2;//sqrt(x.o2 + 0.0001);
        x.data[i] = x.gamma * x.xhat[i] + x.beta;
    }
    return x;
}

//前向传播
cnn_layer CNN_Input(cnn_layer input_image)
{
    int x=0;

    for(int i=0;i<input_image.L;i++){
        for(int j=0;j<input_image.W;j++)
            for(int k=0;k<input_image.C;k++)
            {
                input_image.data[i][j][k]=data[x];
                if(data[x] != 0)
                    cout << "#" << " ";
                else
                    cout << 0 << " ";
                x++;
            }
        cout << endl;
    }
    return input_image;
}

cnn_layer conv(cnn_layer input,cnn_layer conv_w[],int number,cnn_layer output)
{
    memset(output.data,0,sizeof(output.data));

    for(int num=0;num<number;num++)
        for(int i=0;i<input.L;i++)
            for(int j=0;j<input.W;j++)
            {
                for(int k=0;k<conv_w[0].C;k++)
                    for(int a=0;a<conv_w[0].L;a++)
                        for(int b=0;b<conv_w[0].W;b++)
                            output.data[i][j][num] += input.data[i+a][j+b][k] * conv_w[num].data[a][b][k];
                output.data[i][j][num] = Relu(output.data[i][j][num]+output.bias[num]);
            }
    return output;
}

cnn_layer maxpooling(cnn_layer conv_layer,cnn_layer pooling_layer)
{
    for(int k=0;k<conv_layer.C;k++)
        for(int i=0;i<conv_layer.L;i+=2)
            for(int j=0;j<conv_layer.W;j+=2)
                pooling_layer.data[i/2][j/2][k] = max(max(conv_layer.data[i][j][k],conv_layer.data[i+1][j][k]),
                                                      max(conv_layer.data[i][j+1][k],conv_layer.data[i+1][j+1][k]));
    return pooling_layer;
}

fcnn_layer Classify_input(cnn_layer cnn,fcnn_layer fcnn)
{
    int x=0;

    for(int k=0;k<cnn.C;k++)
        for(int i=0;i<cnn.L;i++)
            for(int j=0;j<cnn.W;j++){
                fcnn.data[x] = cnn.data[i][j][k];
                x++;
            }
    return fcnn;
}

fcnn_layer fcnn_Mul(fcnn_layer input,fcnn_layer output)
{
    memset(output.data,0,sizeof(output.data));

    for(int i=0;i<output.L;i++){
        for(int j=0;j<input.L;j++){
            output.data[i] += input.w[i][j]*input.data[j];
        }
        output.data[i] += input.bias[i];
    }
    return output;
}

void forward_propagation()//做一次前向输出
{
    input_layer = CNN_Input(input_layer);
    conv_layer1 = conv(input_layer, cnn_w1, CONV1_O, conv_layer1);

    pool_layer1 = maxpooling(conv_layer1, pool_layer1);
    conv_layer2 = conv(pool_layer1, cnn_w2, CONV2_O, conv_layer2);
    pool_layer2 = maxpooling(conv_layer2, pool_layer2);

    fcnn_input1 = Classify_input(pool_layer2, fcnn_input1);
    for(int i=0; i<fcnn_input1.L; i++)
        cout << fcnn_input1.data[i] << endl;
    fcnn_input1 = BN(fcnn_input1);

    for(int i=0;i<fcnn_input1.L;i++)
        fcnn_input1.data[i] = sigmoid(fcnn_input1.data[i]);

    fcnn_output = fcnn_Mul(fcnn_input1, fcnn_output);
    for(int i=0; i<fcnn_output.L; i++)
        cout << fcnn_output.data[i] << endl;
    fcnn_output = softmax(fcnn_output);
}

//权重初始化
void weights_bias_init()
{
    input_layer.L = 28; input_layer.W = 28; input_layer.C = 1;
    for(int i=0; i<CONV1_O; i++){
        cnn_w1[i].L = 5; cnn_w1[i].W = 5; cnn_w1[i].C = 1;
    }
    conv_layer1.L = 24; conv_layer1.W = 24; conv_layer1.C = CONV1_O;
    pool_layer1.L = 12; pool_layer1.W = 12; pool_layer1.C = CONV1_O;
    for(int i=0; i<CONV2_O; i++){
        cnn_w2[i].L = 5; cnn_w2[i].W = 5; cnn_w2[i].C = CONV1_O;
    }
    conv_layer2.L = 8; conv_layer2.W = 8; conv_layer2.C = CONV2_O;
    pool_layer2.L = 4; pool_layer2.W = 4; pool_layer2.C = CONV2_O;

    fcnn_input1.L = 4*4*CONV2_O;
    fcnn_output.L = 10;
}

double hex48toDouble(string s){
    long long num;
    if (s[0] == '8' || s[0] == '9' || s[0] == 'A' || s[0] == 'B' || s[0] == 'C' || s[0] == 'D' || s[0] == 'E' || s[0] == 'F') {
        for(int i=0; i<12; i++){
            if(s[i] == 'F') s[i] = '0';
            else if(s[i] == 'E') s[i] = '1';
            else if(s[i] == 'D') s[i] = '2';
            else if(s[i] == 'C') s[i] = '3';
            else if(s[i] == 'B') s[i] = '4';
            else if(s[i] == 'A') s[i] = '5';
            else if(s[i] == '9') s[i] = '6';
            else if(s[i] == '8') s[i] = '7';
            else if(s[i] == '7') s[i] = '8';
            else if(s[i] == '6') s[i] = '9';
            else if(s[i] == '5') s[i] = 'A';
            else if(s[i] == '4') s[i] = 'B';
            else if(s[i] == '3') s[i] = 'C';
            else if(s[i] == '2') s[i] = 'D';
            else if(s[i] == '1') s[i] = 'E';
            else if(s[i] == '0') s[i] = 'F';
        }
        std::istringstream iss(s);
        iss >> std::hex >> num;
        num += 1; //补码
        num = -num;
    }
    else{
        std::istringstream iss(s);
        iss >> std::hex >> num;
        //cout << s << " " << num << endl;
    }
    double result = num/65536.0;
    return result;
}

void read_coe(){
    ifstream infile;
    int cnt;
    int co=0;
    int ci=0;
    int l=0;
    int w=0;

    //W1
    co=0;
    ci=0;
    l=0;
    w=0;
    infile.open("W1.coe", ios::in);
    if(!infile.is_open())
        cout << "读取文件失败" << endl;
    char buf1[1000] = { 0 };
    cnt=0;
    while (infile>>buf1){
        if(cnt>4){
            string s = buf1;
            double num = hex48toDouble(s.substr(0,12));
            cnn_w1[co].data[l][w][ci] = num;
            //cout << s << " " << num << " " << co << " " << ci << " " << l << " " << w << endl;
            if(w == cnn_w1[0].W-1){
                w=0;
                if(l == cnn_w1[0].L-1){
                    l=0;
                    if(ci == cnn_w1[0].C-1){
                        ci=0;
                        co++;
                    }
                    else
                        ci++;
                }
                else
                    l++;
            }
            else
                w++;
        }
        cnt++;
    }
    infile.close();

    //b1
    co=0;
    ci=0;
    l=0;
    w=0;
    infile.open("b1.coe", ios::in);
    if(!infile.is_open())
        cout << "读取文件失败" << endl;
    char buf2[1000] = { 0 };
    cnt=0;
    while (infile>>buf2){
        if(cnt>4){
            string s = buf2;
            double num = hex48toDouble(s.substr(0,12));
            conv_layer1.bias[co] = num;
            //cout << s << " " << num << " " << co << " " << ci << " " << l << " " << w << endl;
            co++;
        }
        cnt++;
    }
    infile.close();

    //W2
    co=0;
    ci=0;
    l=0;
    w=0;
    infile.open("W2.coe", ios::in);
    if(!infile.is_open())
        cout << "读取文件失败" << endl;
    char buf3[1000] = { 0 };
    cnt=0;
    while (infile>>buf3){
        if(cnt>4){
            string s = buf3;
            double num = hex48toDouble(s.substr(0,12));
            cnn_w2[co].data[l][w][ci] = num;
            //cout << s << " " << num << " " << co << " " << ci << " " << l << " " << w << endl;
            if(w == cnn_w2[0].W-1){
                w=0;
                if(l == cnn_w2[0].L-1){
                    l=0;
                    if(ci == cnn_w2[0].C-1){
                        ci=0;
                        co++;
                    }
                    else
                        ci++;
                }
                else
                    l++;
            }
            else
                w++;
        }
        cnt++;
    }
    infile.close();

    //b2
    co=0;
    ci=0;
    l=0;
    w=0;
    infile.open("b2.coe", ios::in);
    if(!infile.is_open())
        cout << "读取文件失败" << endl;
    char buf4[1000] = { 0 };
    cnt=0;
    while (infile>>buf4){
        if(cnt>4){
            string s = buf4;
            double num = hex48toDouble(s.substr(0,12));
            conv_layer2.bias[co] = num;
            //cout << s << " " << num << " " << co << " " << ci << " " << l << " " << w << endl;
            co++;
        }
        cnt++;
    }
    infile.close();

    //fcnn_W
    co=0;
    ci=0;
    l=0;
    w=0;
    infile.open("fcnn_W.coe", ios::in);
    if(!infile.is_open())
        cout << "读取文件失败" << endl;
    char buf5[1000] = { 0 };
    cnt=0;
    while (infile>>buf5){
        if(cnt>4){
            string s = buf5;
            double num = hex48toDouble(s.substr(0,12));
            fcnn_input1.w[w][l] = num;
            //cout << s << " " << num << " " << l << " " << w << endl;
            if(l == fcnn_input1.L-1){
                l=0;
                w++;
            }
            else
                l++;
        }
        cnt++;
    }
    infile.close();

    //fcnn_b
    co=0;
    ci=0;
    l=0;
    w=0;
    infile.open("fcnn_b.coe", ios::in);
    if(!infile.is_open())
        cout << "读取文件失败" << endl;
    char buf6[1000] = { 0 };
    cnt=0;
    while (infile>>buf6){
        if(cnt>4){
            string s = buf6;
            double num = hex48toDouble(s.substr(0,12));
            fcnn_input1.bias[co] = num;
            //cout << s << " " << num << " " << co << " " << ci << " " << l << " " << w << endl;
            co++;
        }
        cnt++;
    }
    infile.close();

    //BN
    co=0;
    ci=0;
    l=0;
    w=0;
    infile.open("batch_normalization.coe", ios::in);
    if(!infile.is_open())
        cout << "读取文件失败" << endl;
    char buf7[1000] = { 0 };
    cnt=0;
    while (infile>>buf7){
        if(cnt>4){
            string s = buf7;
            double num = hex48toDouble(s.substr(0,12));
            if(cnt==5)  fcnn_input1.gamma = num;
            if(cnt==6)  fcnn_input1.beta = num;
            //cout << s << " " << num << " " << co << " " << ci << " " << l << " " << w << endl;
        }
        cnt++;
    }
    infile.close();
}

int main() {
    //读取图像
    read_bmp();
    //归一化，绘制图像
    for(int i=0; i<28; i++) {
        for (int j=0; j<28; j++) {
            data[28*i+j] = data[28*i+j]/256.0;
        }
    }

    //读取coe参数，加载参数信息
    weights_bias_init();
    read_coe();
    cout << endl;

    //做一次前向输出
    forward_propagation();
    cout << endl << "result: " << endl;
    for(int i; i<10; i++){
        cout << fcnn_output.data[i] << " ";
    }

    return 0;
}
