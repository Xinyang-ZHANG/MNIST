#include <iostream>
#include <sstream>    //引入stringstream头文件
#include <stdio.h>
#include <iomanip>
#include <bits/stdc++.h>
using namespace std ;

#define u8    unsigned char
#define u32   unsigned int

#pragma pack(1)  //这个选项挺重要，不加的话程序就会报错，原因参考
//https://blog.csdn.net/qq_44310495/article/details/109181857

typedef struct {
    unsigned char bfType[2];
    unsigned long bfSize;
    unsigned short bfReserved1;
    unsigned short bfReserved2;
    unsigned long bfOffBits;
}bitmapFileHeader;

typedef struct {
    unsigned long biSize;
    long biWidth;
    long biHeight;
    unsigned short biPlanes;
    unsigned short biBitCount;
    unsigned long biCompression;
    unsigned long biSizeImage;
    long biXPixPerMeter;
    long biYPixPerMeter;
    unsigned long biClrused;
    unsigned long biClrImportant;
}bitmapInfoHeader;

void read_bmp(int data[784]){
    FILE *fp;
    if((fp=fopen("1.bmp","rb"))==NULL){
        perror("can not open file!");
    }

    bitmapFileHeader bfHeader;
    fread(&bfHeader,14,1,fp);
    bitmapInfoHeader biHeader;
    fread(&biHeader,40,1,fp);

    int imSize=biHeader.biSizeImage;
    int width=biHeader.biWidth;
    int height=biHeader.biHeight;
    int bitCount=biHeader.biBitCount;

    fseek(fp,bfHeader.bfOffBits,SEEK_SET);
    unsigned char* imageData = (unsigned char*)malloc(imSize*sizeof(unsigned char));
    fread(imageData,imSize*sizeof(unsigned char),1,fp);

    //图像为8位图像
    int lineBytes=(bitCount*width+31)/32*4;//得到图像数据的bitwidth'
    int i,j;

    for(i=0;i<height;i++){ //对于每一行
        for(j=0;j<width;j++){ //对于每一列
            data[i*28+j] = *(imageData+lineBytes*(height-1-i)+j); //从最后一行往上读
        }
    }

    free(imageData);
    fclose(fp);
}

int fraction(float fa){
    return (int)((fa-(int)fa)*65536);
}

string dec2hex(float fa) //将int转成16进制字符串，整数32bit小数16bit
{
    int custom_i = fraction(fa);
    int i = (int)fa;
    stringstream ioss_c, ioss; //定义字符串流
    string s_temp_c, s_temp; //存放转化后字符
    ioss_c << setiosflags(ios::uppercase) << hex << custom_i; //以十六制(大写)形式输出
    ioss_c >> s_temp_c;  //小数部分
    ioss << setiosflags(ios::uppercase) << hex << i; //以十六制(大写)形式输出 //ioss << resetiosflags(ios::uppercase) << hex << i; //以十六制(小写)形式输出//取消大写的设置
    ioss >> s_temp; //整数部分

    string result1 = string(8 - s_temp.length(), '0') + s_temp; //整数部分
    string result2 = string(8 - s_temp_c.length(), '0') + s_temp_c; //小数部分
    if(i==0 && custom_i<0)
        result1 = "FFFFFFFF";
    string result = result1 + result2.substr(4,4);
    //cout << result << "\n" << s_temp << " " << s_temp_c << endl;
    return result;
}

void write_coe(int data[784]) {
    FILE *fid_write;
    string s;
    char T1[] = "MEMORY_INITIALIZATION_RADIX = 16;";
    char T2[] = "MEMORY_INITIALIZATION_VECTOR = ";

    fid_write = fopen("one.coe", "w");
    fprintf(fid_write, "%s\n", T1);
    fprintf(fid_write, "%s\n", T2);

    //sigmoid
//    for (int i=-4096;i<4096;i++){
//        float fa = 1.0/(1.0+exp(-(i/409.6)));cout<<fa<<" ";
//        string s;
//        s = dec2hex(fa);
//
//        if(i==4096-1)
//            fprintf(fid_write,"%s;\n",s.c_str());
//        else
//            fprintf(fid_write,"%s,\n",s.c_str());
//    }

    //bmp
    for(int i=0; i<784; i++){
        float temp = (float)data[i]/256;
        s = dec2hex(temp);
        if(i==784-1)
            fprintf(fid_write, "%s;\n", s.c_str());
        else
            fprintf(fid_write, "%s,\n", s.c_str());
    }

    //test
//    s = dec2hex(-0.25);
//    fprintf(fid_write, "%s,\n", s.c_str());
//    s = dec2hex(-70000.1);
//    fprintf(fid_write, "%s,\n", s.c_str());

    fclose(fid_write);
}

int main() {
    int imageData[784];
    read_bmp(imageData);
//    for(int i=0;i<28;i++){ //对于每一行
//        for(int j=0;j<28;j++){ //对于每一列
//            imageData[i*28+j] = i+j;
//            cout << imageData[i*28+j] << " ";
//        }
//        printf("\n");
//    }
    write_coe(imageData);
    return 0;
}
